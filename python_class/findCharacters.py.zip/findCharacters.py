new_word_list = []

word_list = ['hello','world','my','name','is','Anna']
# char = 'o'
for i in word_list:
    print i
    if "o" in i:
        new_word_list.append(i)
print new_word_list
