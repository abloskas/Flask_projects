for i in range(1, 25):
    if i% 2 == 0:
        print(" * * * *")
    else:
        print("* * * *")
	