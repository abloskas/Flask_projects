
for i in range (1,1000,2):
    print i

for i in range(0,1000000+1,5):
    print i

a = [1, 2, 5, 10, 255, 3]
print sum(a)

a = [1, 2, 5, 10, 255, 3]
b = sum(a)
c = len(a)
x = b/c
print x

